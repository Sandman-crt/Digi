import React, { useState } from "react";
export default function DigiSOAPInvoiceUI() {
  const [subjective, setSubjective] = useState("");
  const [objective, setObjective] = useState("");
  const [assessment, setAssessment] = useState("");
  const [plan, setPlan] = useState("");
  const [aiSuggestions] = useState({
    subjective: "Property reports DHW equipment leaking in mechanical room.",
    objective: "Observed base leak on commercial water heater; documented model/serial, PRV brand/age, mixing valve, recirc status.",
    assessment: "Replaced equipment like-for-like; serviced recirc/mixing as specified; updated isolation valves with ProPress full-port; documented commissioning.",
    plan: "No follow-up required / schedule after-hours balancing / monitor return temps.",
  });
  const ADMIN_PASSPHRASE = "Spacepanda";
  const [admin, setAdmin] = useState(false);
  const handleAutoFill = () => {
    setSubjective(aiSuggestions.subjective);
    setObjective(aiSuggestions.objective);
    setAssessment(aiSuggestions.assessment);
    setPlan(aiSuggestions.plan);
  };
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-6">
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-2xl font-bold">DIGI Invoice Notes (SOAP Format) — Commercial</h1>
        <div className="bg-white rounded-xl shadow p-5 space-y-4">
          <div><label className="font-semibold">S – Subjective</label>
            <textarea value={subjective} onChange={e=>setSubjective(e.target.value)} className="w-full p-2 mt-1 border rounded-md" rows={2}/>
          </div>
          <div><label className="font-semibold">O – Objective</label>
            <textarea value={objective} onChange={e=>setObjective(e.target.value)} className="w-full p-2 mt-1 border rounded-md" rows={3}/>
          </div>
          <div><label className="font-semibold">A – Assessment</label>
            <textarea value={assessment} onChange={e=>setAssessment(e.target.value)} className="w-full p-2 mt-1 border rounded-md" rows={2}/>
          </div>
          <div><label className="font-semibold">P – Plan</label>
            <textarea value={plan} onChange={e=>setPlan(e.target.value)} className="w-full p-2 mt-1 border rounded-md" rows={2}/>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={handleAutoFill} className="bg-indigo-600 text-white px-4 py-2 rounded-xl">Auto-Fill</button>
            <button onClick={()=>{navigator.clipboard.writeText(`S: ${subjective}\nO: ${objective}\nA: ${assessment}\nP: ${plan}`);alert("Copied.");}} className="bg-emerald-600 text-white px-4 py-2 rounded-xl">Copy</button>
            {!admin && <button onClick={()=>{const p=prompt("Admin passphrase?");if(p===ADMIN_PASSPHRASE){setAdmin(true);alert("Admin mode activated. Welcome back, boss.");}}} className="bg-slate-800 text-white px-4 py-2 rounded-xl">Admin</button>}
          </div>
        </div>
      </div>
    </div>
  );}
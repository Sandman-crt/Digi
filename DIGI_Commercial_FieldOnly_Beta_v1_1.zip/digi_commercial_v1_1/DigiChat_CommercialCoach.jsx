import React, { useMemo, useRef, useState } from "react";
const ADMIN_PASSPHRASE = "Spacepanda";
const RE_APPROVAL = /(corporate|approval|po\b|purchase order|owner|management|waiting on)/i;
const RE_PRICE = /(too expensive|too high|budget|over budget|cost too much|need cheaper)/i;
const RE_VENDOR = /(multiple bids|more quotes|other vendor|competitive bid)/i;
const RE_TENANT = /(tenant|resident|occupant).*(upset|angry|mad|complain|access|after-hours)/i;
const RE_WARRANTY = /(warranty|covered)/i;
function buildCommercialOptions(ctx){
  const equipment = ctx.jobType || "Commercial DHW heater";
  return [
    { tier:"Platinum", scope:[
      `Replace ${equipment} with Rheem commercial (or Navien rack if utilities/space support)`,
      "Install Watts PRV if pressure out of spec; tag final setting",
      "Service/replace mixing valve; document outlet temps at far fixture",
      "Balance recirc; verify return temps and checks",
      "Add/replace ProPress full-port isolation valves; update labeling/signage",
      "Start-up & commissioning docs; debris removal",
      "Offer after-hours scheduling to minimize disruption"
    ]},
    { tier:"Gold", scope:[
      `Replace ${equipment} like-for-like (Rheem commercial)`,
      "Address PRV OR mixing valve (whichever is failing/out of range)",
      "Replace critical isolation valves (ProPress full-port)",
      "Verify recirc function; basic balancing",
      "Commissioning photos/documentation"
    ]},
    { tier:"Silver", scope:[
      `Replace ${equipment} like-for-like`,
      "Replace single ancillary (expansion tank OR isolation valves)",
      "Basic documentation/photos"
    ]},
    { tier:"Bronze", scope:[
      "Minimal component repair/replacement to restore service",
      "List deferred compliance items for next PO"
    ]}
  ];
}
const coach = {
  approval:[
    "Let me own the email thread. I’ll send a one‑pager with scope, price, and downtime risk. If they reply 'approved', we’ll finish today or after‑hours—your call.",
    "I can include photos and line items so approval is quick and apples‑to‑apples."
  ],
  price:[
    "Gold/Silver keep you compliant without extras; Bronze restores service today with deferred items listed for the next PO.",
    "This prevents additional downtime and re-dispatches; we can phase if needed."
  ],
  vendor:["I’ll attach photos and a line‑item scope so your comparison is apples‑to‑apples. We can hold today’s slot while you compare."],
  tenant:["We can stage by stack/wing or schedule after‑hours to minimize impact. I’ll keep you updated during shutoffs."],
  warranty:["We’ll separate any warranty‑eligible parts and document non‑covered system issues clearly for your records."]
};
function routeInline({messages}){
  const last = [...messages].reverse().find(m=>m.role==="tech");
  if(!last) return [];
  const t = last.text;
  if(RE_APPROVAL.test(t)) return coach.approval;
  if(RE_PRICE.test(t)) return coach.price;
  if(RE_VENDOR.test(t)) return coach.vendor;
  if(RE_TENANT.test(t)) return coach.tenant;
  if(RE_WARRANTY.test(t)) return coach.warranty;
  return [];
}
export default function DigiChat_CommercialField(){
  const [messages, setMessages] = useState([
    { role:"digi", text:"Commercial field-only mode. Describe findings (e.g., 'water heater leaking at base; PRV 110 psi; mixing valve stuck'). Type 'options' to build Platinum→Bronze. Type 'make me an invoice' for SOAP." }
  ]);
  const [input, setInput] = useState("");
  const [ctx, setCtx] = useState({ jobType:"Commercial water heater", property:"[Property/Unit]" });
  const [admin, setAdmin] = useState(false);
  const listRef = useRef(null);
  const scroll = () => requestAnimationFrame(()=> listRef.current?.scrollTo({top:listRef.current.scrollHeight, behavior:"smooth"}));
  function send(){
    if(!input.trim()) return;
    const text = input.trim();
    let next = [...messages, {role:"tech", text}];
    if(/^options$/i.test(text)){
      const pkgs = buildCommercialOptions(ctx);
      next.push({role:"digi", text: "Here are your commercial options (field-only):"});
      pkgs.forEach(p=> next.push({role:"digi", text:`🔹 ${p.tier}\n- ${p.scope.join("\n- ")}`}));
      setMessages(next); setInput(""); scroll(); return;
    }
    if(/^make me an invoice$/i.test(text)){
      const techNotes = [...messages, {role:"tech", text}].filter(m=>m.role==="tech").slice(-5).map(m=>m.text).join(" ");
      const soap = `S: Property reported issue; tech onsite.\nO: ${techNotes}\nA: Work performed per selected option (see scope and commissioning docs).\nP: No follow-up / after-hours balancing / monitor temps (as applicable).`;
      next.push({role:"digi", text:`🧾 SOAP (commercial):\n${soap}`});
      setMessages(next); setInput(""); scroll(); return;
    }
    const coaching = routeInline({messages: next});
    if(coaching.length){ coaching.forEach(c => next.push({role:"digi", text:"💡 " + c})); }
    setMessages(next); setInput(""); scroll();
  }
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-6">
      <div className="max-w-4xl mx-auto space-y-4">
        <h1 className="text-2xl font-bold">DIGI — Commercial Field-Only</h1>
        <div className="bg-white rounded-xl shadow p-4 flex flex-wrap items-center gap-3 text-sm">
          <div><label className="mr-2 font-semibold">Property</label><input className="border rounded px-2 py-1" value={ctx.property} onChange={e=>setCtx({...ctx, property:e.target.value})}/></div>
          <div><label className="mr-2 font-semibold">Job</label><input className="border rounded px-2 py-1" value={ctx.jobType} onChange={e=>setCtx({...ctx, jobType:e.target.value})}/></div>
          {!admin && <button onClick={()=>{const p=prompt("Admin passphrase?"); if(p===ADMIN_PASSPHRASE){setAdmin(true); alert("Admin mode activated. Welcome back, boss.");}}} className="ml-auto bg-slate-800 text-white px-3 py-1 rounded-lg text-xs">Admin</button>}
        </div>
        <div ref={listRef} className="h-[420px] bg-white rounded-xl shadow p-4 overflow-y-auto space-y-3">
          {messages.map((m,i)=>(
            <div key={i} className={`max-w-[85%] rounded-2xl px-4 py-2 shadow ${m.role==="tech" ? "bg-indigo-50 ml-auto" : "bg-slate-100"}`}>
              <div className="text-[11px] uppercase tracking-wide mb-1 text-slate-500">{m.role==="tech" ? "Tech" : "DIGI"}</div>
              <div className="text-sm whitespace-pre-wrap">{m.text}</div>
            </div>
          ))}
        </div>
        <div className="bg-white rounded-xl shadow p-3 flex gap-2 items-center">
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=> (e.key==="Enter" && !e.shiftKey ? (e.preventDefault(), send()) : null)} placeholder="Type findings, or 'options', or 'make me an invoice'..." className="flex-1 border rounded-lg px-3 py-2"/>
          <button onClick={send} className="bg-indigo-600 text-white px-4 py-2 rounded-lg">Send</button>
        </div>
      </div>
    </div>
  );
}

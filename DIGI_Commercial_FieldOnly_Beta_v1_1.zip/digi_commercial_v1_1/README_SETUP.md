# DIGI Technician AI Assistant — Commercial Field-Only (Internal Beta v1.1)

**Admin Passphrase:** `Spacepanda` → shows “Admin mode activated. Welcome back, boss.”

This build removes dispatcher flow and residential upsells. It is optimized for commercial/multifamily field technicians **onsite**.

## What’s New in v1.1
- Field-only behavior (assume tech is onsite)
- Commercial packages (no filtration upsell): Platinum/Gold/Silver/Bronze
- Coaching for PO/approvals, budget, multiple bids, tenant impact, warranty
- “Make me an invoice” → SOAP from conversation in commercial tone

## Contents
- `DigiChat_CommercialCoach.jsx` — Chat UI with inline commercial coaching + email draft.
- `DigiSOAPInvoiceUI.jsx` — SOAP invoice generator UI with clipboard.
- `DIGI_Manifest.json` — Paste into GPT Builder → Instructions.
- `README_SETUP.md` — This file.
- `LICENSE.txt` — Internal use only.
- (Optional, if present) Slides/handout files.

© 2025 BlueFlow — Internal Use Only.
